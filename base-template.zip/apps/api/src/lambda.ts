import serverlessExpress from "@vendia/serverless-express";
import type { Handler } from "aws-lambda";

import { createNestApplication } from "./server";

let cachedHandler: Handler | undefined;

export const handler: Handler = async (event, context, callback) => {
  if (!cachedHandler) {
    const app = await createNestApplication();
    await app.init();

    cachedHandler = serverlessExpress({
      app: app.getHttpAdapter().getInstance()
    });
  }

  return cachedHandler(event, context, callback);
};
