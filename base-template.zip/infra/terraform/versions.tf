terraform {
  required_version = ">= 1.9.0"

  backend "s3" {}

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.59"
    }

    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}
